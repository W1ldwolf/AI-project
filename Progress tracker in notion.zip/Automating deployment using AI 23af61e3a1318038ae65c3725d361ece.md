# Automating deployment using AI

- [ ]  **Generating sample PL/SQL code for order management process in WMS**
- [ ]  **Deploy the code to GitHub using cursor IDE**
- [ ]  **Make changes to the PL/SQL code as per requirement using cursor IDE**
- [ ]  **Deploy the code oracle DB**
- [ ]  **Perform DB validations for the deployed package**
- [ ]  **Perform sanity testing for the deployed package**

## 1.Generating sample PL/SQL code for order management process in WMS:

**AI prompt:** Generate a sample PL/SQL code for order management process in the warehouse and provide all the components associated with the package to deploy them into Oracle DB.

## **2.Deploy the code to GitHub using cursor IDE**

Used cursor IDE to push the code to GitHub repository.

## **3.Make changes to the PL/SQL code as per requirement using cursor IDE**

**AI prompt:** Include a condition to restrict the order id in Orders table within 999999. If the customer id pass behind 999999, reset the order id to 1 and continue. Using Order Management Process PL/SQl block, suggest the best place to include the condition and show the inserted version of the procedure as well for the confirmation. Once confirmed, add the updated PL/SQL package to a new file and push the file to my Git repository

![image.png](image.png)

Next steps:

Exploring how to automate DB installation and committing the required changes directly to my local oracle database

[https://www.oracle.com/in/database/technologies/oracle-database-software-downloads.html#db_ee](https://www.oracle.com/in/database/technologies/oracle-database-software-downloads.html#db_ee)

Challenges faced:

Gitpush command is being executed automatically by the AI

![image.png](image%201.png)